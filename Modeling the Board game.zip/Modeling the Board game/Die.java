import java.util.Random;

public class Die {
    private int lastRoll;

    public Die() {
        roll(); // Initialize with a random roll
    }

    public int roll() {
        Random random = new Random();
        lastRoll = random.nextInt(6) + 1; // Random number between 1 and 6
        return lastRoll;
    }

    public int getLastRoll() {
        return lastRoll;
    }
}