public class DieTest {
    public static void main(String[] args) {
        System.out.println("Testing Die class...");

        // Test roll() method
        Die die = new Die();
        System.out.println("Testing roll() method:");
        for (int i = 0; i < 10; i++) {
            int roll = die.roll();
            System.out.println("Roll " + (i + 1) + ": " + roll);
            if (roll < 1 || roll > 6) {
                System.out.println("FAIL: Roll value out of range [1, 6]");
                return;
            }
        }
        System.out.println("PASS: roll() method works as expected.");

        // Test getLastRoll() method
        System.out.println("\nTesting getLastRoll() method:");
        int lastRoll = die.getLastRoll();
        System.out.println("Last roll value: " + lastRoll);
        if (lastRoll < 1 || lastRoll > 6) {
            System.out.println("FAIL: Last roll value out of range [1, 6]");
            return;
        }
        System.out.println("PASS: getLastRoll() method works as expected.");
    }
}