public class DiceTest {
    public static void main(String[] args) {
        System.out.println("Testing Dice class...");

        // Create Dice object and add Die objects
        Dice dice = new Dice();
        Die die1 = new Die();
        Die die2 = new Die();
        dice.addDie(die1);
        dice.addDie(die2);

        // Test dieAt() method
        System.out.println("\nTesting dieAt() method:");
        Die retrievedDie1 = dice.dieAt(0);
        Die retrievedDie2 = dice.dieAt(1);
        if (retrievedDie1 != die1 || retrievedDie2 != die2) {
            System.out.println("FAIL: dieAt() method did not return the correct Die object.");
            return;
        }
        System.out.println("PASS: dieAt() method works as expected.");

        // Test roll() and getTotalValue() methods
        System.out.println("\nTesting roll() and getTotalValue() methods:");
        int total = dice.roll();
        System.out.println("Total value after roll: " + total);
        if (total < 2 || total > 12) {
            System.out.println("FAIL: Total value out of range [2, 12]");
            return;
        }
        System.out.println("PASS: roll() and getTotalValue() methods work as expected.");

        // Test allSame() method
        System.out.println("\nTesting allSame() method:");
        boolean allSame = dice.allSame();
        System.out.println("All dice have the same value: " + allSame);

        // Force dice to have the same value for testing
        die1.roll();
        die2.roll();
        while (die1.getLastRoll() != die2.getLastRoll()) {
            die2.roll();
        }
        allSame = dice.allSame();
        System.out.println("After forcing dice to have the same value, allSame(): " + allSame);
        if (!allSame) {
            System.out.println("FAIL: allSame() method did not return true when all dice have the same value.");
            return;
        }
        System.out.println("PASS: allSame() method works as expected.");
    }
}